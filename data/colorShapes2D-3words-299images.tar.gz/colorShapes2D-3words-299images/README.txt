README.txt
----------
colorShapes2D-3words-299images is a set of a total of 299 images, composed of circles
that are affected by three word descriptions, which correspond to:

vpos: bottom (20,+-10) / middle (50,+-10) / top (80,+-10) -> [0,100]
hpos: left (20,+-10) / middle (50,+-10) / right (80,+-10) -> [0,100]
hue: red (10,+-20) / green (70,+-20) / green (130,+-20) -> [0,180]

where noise is a non-normalized rand() around (...,) and comprehended between the values (,...).

Thus the name format includes the 3 descriptors, and a unique identifier:
vpos_hpos_hue_id.ppm

These images were generated using -r 2097 of
$XGNITIVE_ROOT/main/src/modules/imgGeneratorFigs, mainly made by Santiago Morante to generate
.png files using opencv, and passed through mogrify to convert to .ppm.

Legal
-----
Copyright: 2013 (C) Universidad Carlos III de Madrid

Authors: <a href="http://roboticslab.uc3m.es/roboticslab/persona_publ.php?id_pers=72">Juan G. Victores</a>,
<a href="http://www.mendeley.com/profiles/santiago-morante-cendrero/">Santiago Morante</a>

CopyPolicy: This dataset is available under the Creative Commons Attribution License
(http://creativecommons.org/licenses/by/3.0/).

